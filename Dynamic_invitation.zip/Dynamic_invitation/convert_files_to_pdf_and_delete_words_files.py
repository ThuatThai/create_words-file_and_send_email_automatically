import os
from pathlib import Path
from docx2pdf import convert

def convert_files_to_pdf(directory):
    for file_path in Path(directory).iterdir():
        if file_path.suffix.lower() == ".docx":
            pdf_path = file_path.with_suffix(".pdf")
            convert(file_path, pdf_path)
            print(f"File converted: {file_path} -> {pdf_path}")
            file_path.unlink()

# Ví dụ sử dụng
directory = ".\emai_to"
convert_files_to_pdf(directory)
