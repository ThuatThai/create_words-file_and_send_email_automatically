from docx import Document
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import os

def send_email(sender_email, sender_password, recipient_email, subject, body, attachment_path):
    # Tạo đối tượng MIMEMultipart để chứa nội dung email
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = f"Kính chào quý khách hàng {subject}"

    # Thêm nội dung văn bản vào email
    msg.attach(MIMEText(body, 'plain'))

    # Đính kèm file PDF vào email
    with open(attachment_path, "rb") as attachment:
        part = MIMEApplication(attachment.read(), Name=os.path.basename(attachment_path))
    part['Content-Disposition'] = f'attachment; filename="{os.path.basename(attachment_path)}"'
    msg.attach(part)

    # Gửi email
    with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
        smtp.starttls()
        smtp.login(sender_email, sender_password)
        smtp.send_message(msg)


def attach_and_send_emails(sender_email, sender_password, directory):
    for filename in os.listdir(directory):
        if filename.endswith(".pdf"):
            file_path = os.path.join(directory, filename)
            recipient_email = get_recipient_email(file_path)
            if recipient_email:
                attachment_name = recipient_email.split("@")[0]  # Lấy tên người nhận từ địa chỉ email
                subject = recipient_email
                body = "Trân trọng kính chào quý khách.\n" \
                       "Chúng tôi xin phép gửi đến quý khách thư mời tham gia sự kiện.\n" \
                       "Xin quý khách vui lòng kiểm tra tệp được đính kèm.\n" \
                       "Trân trọng cảm ơn"

                send_email(sender_email, sender_password, recipient_email, subject, body, file_path)


def get_recipient_email(file_path):
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    return file_name


# Thông tin tài khoản email người gửi
sender_email = "lgio.cnc@gmail.com"
sender_password = "lxhhvguinexbedmq"

# Đường dẫn thư mục chứa các file PDF cần đính kèm và gửi
directory = ".\emai_to"

# Attach và gửi email
attach_and_send_emails(sender_email, sender_password, directory)
